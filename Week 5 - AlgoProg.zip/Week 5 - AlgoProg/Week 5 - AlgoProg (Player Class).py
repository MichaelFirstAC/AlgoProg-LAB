'''RAAAAAAAAAAAAAAAAAAAAHHHHHH'''
'''THIS TOOK ME 4 YOUTUBE TUTORIALS AND 2 HOURS TO MAKE- RAAAHHHHHHH'''

class Astrid:
    def __init__(self, name, health=100, money=100):
        self.name = name
        self.health = health
        self.money = money
        self.inventory = {}

    def add_item(self, item_name, quantity=1):
        
        # Add an item to the inventory.
        #   item_name (str): The name of the item.
        #   quantity (int, optional): The quantity of the item. Default is 1.
        
        if item_name in self.inventory:
            self.inventory[item_name] += quantity
        else:
            self.inventory[item_name] = quantity

    def remove_item(self, item_name, quantity=1):
        
        # Remove an item from the inventory.
        #   item_name (str): The name of the item.
        #   quantity (int, optional): The quantity of the item. Default is 1.
        
        if item_name in self.inventory:
            if self.inventory[item_name] >= quantity:
                self.inventory[item_name] -= quantity
            else:
                print("Not enough things in inventory.")
        else:
            print("Item not found in inventory.")

    def increase_money(self, amount):
        
        # Increase the player's money.
        #   amount (int): The amount to increase.
        
        self.money += amount

    def decrease_money(self, amount):
        
        # Decrease the player's money.
        #   amount (int): The amount to decrease.
        
        if self.money >= amount:
            self.money -= amount
        else:
            print("Not enough money. Broke ahh lmao.")

    def increase_health(self, amount):
        
        # Increase the player's health.
        #   amount (int): The amount to increase.
        
        self.health += amount

    def decrease_health(self, amount):
        
        # Decrease the player's health.
        #   amount (int): The amount to decrease.
        
        if self.health >= amount:
            self.health -= amount
        else:
            self.health = 0
            print("Dead. HAHAHAHAHAHAHAA-")

    def display_status(self):
        
        # Display the player's status.
        
        print(f"Name: {self.name}")
        print(f"Health: {self.health}")
        if self.health <= 0:
            print("Youre dead. Lmao-")
        print(f"Money: {self.money}")
        if self.money <= 0:
            print("Mf is really broke- HAHAHAHA")
        print("Inventory:")
        for item, quantity in self.inventory.items():
            print(f"{item}: {quantity}")


# Example usage:
def main():
    name = input("Enter your name: ")
    astrid = Astrid(name)

    while True:
        print("\nOptions:")
        print("1. Add item to inventory")
        print("2. Remove item from inventory")
        print("3. Increase money +$")
        print("4. Decrease money -$")
        print("5. Increase health")
        print("6. Decrease health")
        print("7. Display status")
        print("8. Quit")

        choice = input("Enter your choice: ")

        if choice == "1":
            item_name = input("Enter item name: ")
            quantity = int(input("Enter quantity (default = 1): ") or 1)
            astrid.add_item(item_name, quantity)
        elif choice == "2":
            item_name = input("Enter item name: ")
            quantity = int(input("Enter quantity (default = 1): ") or 1)
            astrid.remove_item(item_name, quantity)
        elif choice == "3":
            amount = int(input("Enter amount: "))
            astrid.increase_money(amount)
        elif choice == "4":
            amount = int(input("Enter amount: "))
            astrid.decrease_money(amount)
        elif choice == "5":
            amount = int(input("Enter amount: "))
            astrid.increase_health(amount)
        elif choice == "6":
            amount = int(input("Enter amount: "))
            astrid.decrease_health(amount)
        elif choice == "7":
            astrid.display_status()
        elif choice == "8":
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()