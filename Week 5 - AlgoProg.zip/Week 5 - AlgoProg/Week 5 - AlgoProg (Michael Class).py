'''RAAAAAAAAAAAHHHHHH'''
'''This was unecessarily annoying to make. But so worth it. I can kill myself, ingame ofc! wow!'''

class Michael:
    
    # Michael's class
    # Self thing for mikel
    def __init__(self):
        self.energy = 100
        self.mood = "Neutral. (For now...)"
        self.skills = []
        self.hobbies = []
        self.tasks_completed = 0

    # Skill issue for mikel
    def learn_skill(self):
        skill = input("Enter a new skill to learn (except mewing. He knows that alrd.): ")
        self.skills.append(skill)
        self.mood = "accomplished. Phew. i thought he'll fail. lmao."
        print(f"Michael learned {skill} and feels {self.mood}! (No he doesnt. He's getting sick of you.)")

    # hobbies for this sorry ahh
    def pick_up_hobby(self):
        hobby = input("Enter a new hobby to pick up (Hopefully not anything... weird): ")
        self.hobbies.append(hobby)
        self.mood = "Unusually excited? what. huh?"
        print(f"Michael picked up {hobby} and feels {self.mood}! thats... weird.")

    # tasks completed for mikel. (I doubt he submitted any, pfft- what a loser.)
    def complete_task(self):
        if self.energy >= 20:
            self.energy -= 20
            self.tasks_completed += 1
            print(f"Michael completed a task and has {self.energy} energy left. He's getting tired of you.")
            if self.energy < 30:
                self.mood = "tired (dead. actually. but i had to keep this pg-13.)"
                print(f"Michael is feeling {self.mood} after completing the task. He's getting tired bro. stop.")
        else:
            print("Michael doesn't have enough energy to complete a task. He's fucking dead bro. stop.")

    # Recharging his mental capacity. (Caffeine probably.)
    def recharge(self):
        self.energy = 100
        self.mood = "refreshed (the only thing keeping him going is 5000 grams of pure unfiltered caffeine.)"
        print("Michael recharged his energy and feels refreshed! (Coffee really does its wonders huh?)")

    # Self reflection. (fyi: He did terrible.)
    def reflect(self):
        print("Michael's (totally useful) skills!:")
        for skill in self.skills:
            print(f"- {skill}")
        print("Michael's (totally not weird) hobbies!:")
        for hobby in self.hobbies:
            print(f"- {hobby}")
        print(f"Michael has completed {self.tasks_completed} tasks. Yippie i guess.")

    # check his mood. see if he's still willing to live.
    def check_mood(self):
        print(f"Michael is feeling {self.mood}.")

    # the main thingymajig. to see michael and all his glory.
    def main_loop(self):
        while True:
            print("\nWhat would you like to do today? except committing crimes?")
            print("1. Learn a new unusual skill")
            print("2. Pick up a new weird hobby")
            print("3. Complete a task not willingly")
            print("4. Recharge energy with coffee")
            print("5. Reflect on skills and hobbies")
            print("6. Check current will to live")
            print("7. Quit. (Please.)")

            choice = input("Enter your choice (1-7): ")

            if choice == "1":
                self.learn_skill()
            elif choice == "2":
                self.pick_up_hobby()
            elif choice == "3":
                self.complete_task()
            elif choice == "4":
                self.recharge()
            elif choice == "5":
                self.reflect()
            elif choice == "6":
                self.check_mood()
            elif choice == "7":
                print("Goodbye! (GO AWAY. FOREVER. PLEASE.)")
                break
            else:
                print("Bro. how hard is it to type 1-7. Idiot.")

    # to start this awesome mechanism.
    
michael = Michael()
michael.main_loop()