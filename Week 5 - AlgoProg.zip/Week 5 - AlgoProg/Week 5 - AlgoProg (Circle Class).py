'''RAAAAAAAAAAAAAHHHHHH'''

class Circle:
    def __init__(self, radius, color):
        self.__radius = radius
        self.__color = color
        self.__pi = 3.14

    def getColor(self):
        return self.__color

    def getCircum(self):
        return 2 * self.__pi * self.__radius

def main():
    # Get user input for radius and color
    radius = float(input("Enter the radius of the roundy thingymajig: "))
    color = input("Enter the color of the skin- i mean... circle: ")
    
    if color == 'black' or 'Black' or 'BLACK':
        print('Aww hell nah, why that of all the colors?')
    else:
        print('Okay phew- thought you were gonna input the bad color.')

    # Create a Circle object with user input
    circle = Circle(radius, color)

    # Print the color and circumference of the circle
    print(f"Color: {circle.getColor()}")
    print(f"Circumference: {circle.getCircum():.2f}")

if __name__ == "__main__":
    main()